#include "scoring_matrix.h"

#include <stdio.h>
#include <string.h>

//author - Robbie Thomson 2314819t

scoring_matrix create_matrix(const char *a, const char *b, int match_score, int gap_cost)
{
    //initialise the scoring matrix width and height
    size_t width = (strlen(a)+1);
    size_t height = (strlen(b)+2);
    //allocate memory for the data
    int *data_size = malloc(width*height*sizeof(int));

    //instanciate the scoring matrix
    scoring_matrix matrix = {width, height, data_size}; // change this!!

    //fill the first row with 0s
    for (int i=0; i<width; i++)
    { *(data_size + i) = 0; }
    // fill the first column with 0s
    for (int i=0; i<height; i++)
    { *(data_size + i*width) = 0; }

        
    //itterate through rows 
    for(int rows=1; rows<height; rows++)
    {
        //itterate through the collumns of the current row
        for (int columns=1; columns<width; columns++)
        {
            //calculate all the options for filling the matrix with values
            int data_M = 0;
            int data_A = *(data_size + (rows-1)*width + (columns-1)) + (a[rows-1]==b[columns-1] ? match_score : -match_score);
            int data_B = *(data_size + (rows-1)*width + (columns)) - gap_cost;
            int data_C = *(data_size + (rows)*width + (columns-1)) - gap_cost;

            //find the maximum of the values calculated
            if(data_A > data_M)
            { data_M = data_A; } 
            if(data_B > data_M)
            { data_M = data_B; }
            if(data_C > data_M)
            { data_M = data_C; }     
            
            //fill the matrix element with the maximum value calculated
            *(data_size + rows*width +columns) = data_M;
        }
    }
    //return the scoring matrix
    return matrix;
}


void free_matrix(scoring_matrix matrix)
{
    //free the memory used for the matrix
    free(matrix.data);
}


scoring_matrix_view matrix_as_view(scoring_matrix matrix)
{
    //create a view of the matrix
    scoring_matrix_view view = {matrix.width, matrix.height, matrix};
    return view;
}


void print_matrix(scoring_matrix_view view)
{
    ///itterate through rows 
    for (int row=0; row<view.height; row++)
    {
        //itterate through the collumns of the current row
        for(int column=0; column<view.width; column++)
        {
            //print the value in the matrix at current position of iteration
            printf("%d \t",*(view.matrix.data + row*view.width + column));
        }
        //print a new line to so values printed are alligned properly
        printf("\n");

    }
}