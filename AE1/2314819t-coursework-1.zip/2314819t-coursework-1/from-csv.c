#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "Smith-Waterman.h"

//author - Robbie Thomson 2314819t

char * clean(char *string)
{
    //find the length of the string
    int len = strlen(string);
    int blanks = 0;

    //count the number od "space" characters there are in the string
    while (string[blanks] == ' ' && len >= blanks)
    { blanks++; }

    //itterate the string
    for (int b = blanks; b < len; b++)
    {
        //remoce the spaces and new lines
        if(string[b] == ' ' || string[b] == '\n')
        { string[b] = '\0'; }
    }
    return string + blanks;
}

void cvs_printer(FILE *fileP)
{
    //initialise vaiables and pointers
    char *str_1;
    char *str_2;
    char *tok;
    char line[257];

    //itterate the lines of the file
    while (fgets(line, 257, fileP) !=NULL)
    {
        //do nothing and go to next line if line starts with "#"
        if (line[0] == '#')
        { continue; }
        else{
            //call clean on first token
            tok = strtok(line, ",");
            str_1 = clean(tok);
            //call clean of second token
            tok = strtok(NULL, ",");
            str_2 = clean(tok);
    
            //use the 2 tokens as paramenters for the smith waterman algorithm
            print_smith_waterman(str_1, str_2);
        } 
    }

}

int main(int argc, char **argv)
{
    //initialise pointers
    FILE *f_pnt;
    char *ProgFile;
    
    //point to file name
    ProgFile = argv[1];
    //open csv file 
    f_pnt = fopen(ProgFile, "rb");
    
    //check if file loaded properly
    if(f_pnt == NULL)
    {
        fprintf(stderr, "File not able to be opened\n");
        return EXIT_FAILURE;
    }

    //call printer function on the file
    cvs_printer(f_pnt);
    //close the file
    fclose(f_pnt);
    return EXIT_SUCCESS;
}

// first command line argument (stored in argv[1]) is the csv filename
    // open the csv file
    // load in csv line-by-line (ignoring lines starting by #;
    //                           you can assume that a line will be never
    //                           longer than 256 characters)
    // for each line:
    //   read string up to `,' as the first string
    //   read string after `,' up to the newline character as the second string
    //   remove whitespace at the start and end of each string
    //   call `print_smith_waterman' with the first and second string
    // close the csv file