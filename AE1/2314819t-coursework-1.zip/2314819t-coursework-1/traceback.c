#include "traceback.h"

#include <string.h>
#include <stdio.h>

//author - Robbie Thomson 2314819t

int * Maximum(scoring_matrix_view view)
{
    //initialise maximum pointer
    int *max_point = view.matrix.data;
    //itterate through given rows
    for (int h = 0 ; h < view.height; h++)
    {
        //itterate given columns at current row
        for (int w = 0 ; w < view.width; w++)
        {
            //initialise the current matrix value
            int *curr = view.matrix.data + h*view.matrix.width +w;
            //decide if current vaximum is smaller than the current value 
            if (*max_point <= *curr)
            //set a new maximum to the current value
            { max_point = curr; }
        }
    }
    //return the maximum value in the dimensions of th ematrix
    return max_point;
}


void traceR (traceback_result *result, scoring_matrix_view view, const char* a, const char* b, int offS, int old)
{
    //assign the new maximun value within matrix limits 
    int *pointR = Maximum(view);
    //find the width of the matrix width and height from the top left corner down to the maximum value
    int wid = (pointR - view.matrix.data) % view.matrix.width;
    int hei = (pointR - view.matrix.data) / view.matrix.width;

    //base case putting the alligned value into into the first string 
    if (*(view.matrix.data + hei*view.matrix.width + wid) == 0)
    {
        strncpy(result->a_, a+wid, strlen(result->b_));
        //return nothing and exit the function back to the main
        return;
    }
    //check of the next highest value was not to the top right oh the previous
    if (old - hei > 1)
    {    
        //add a "-" to the second string where there is no aligning value
        strncpy(result->b_+wid-offS, "-", 1);
        offS += 1;
    }
    //add the ealigning value into the second string 
    strncpy(result->b_+wid-offS, b+wid-1, 1);
 
    //adjust the height and width for the next recursion
    view.height = hei;
    view.width = wid;
    //recur the function
    traceR(result, view, a, b, offS, hei);
}


traceback_result *traceback(scoring_matrix_view view, const char* a, const char* b) 
{
    //check if the parameters are valid
    if (a == NULL || b == NULL)
    {
        //print error message and exit function
        fprintf(stderr, "Traceback parameters not valid");
        exit(EXIT_FAILURE);
    }

    //allocate memory for results
    traceback_result * tb_result = malloc(sizeof(traceback_result));
    //check if the memory was allocated properly
    if (tb_result == NULL)
    {
        //print error message and exit function
        fprintf(stderr, "Traceback result memory allocation failed as memory ran out");
        exit(EXIT_FAILURE);
    }

    //initialise characters
    size_t chars = (view.height) + 1;
    //allocate memory for attributes in struct
    tb_result->a_ = malloc(chars * sizeof(char));
    tb_result->b_ = malloc(chars * sizeof(char));
    //check if memory is allocated properly
    if (tb_result->a_ == NULL || tb_result->b_ == NULL)
    {
        //print error message and exit function
        fprintf(stderr, "Traceback string memory allocation fails as memory ran out");
        exit(EXIT_FAILURE);
    }

    //put 0 values into the attributes
    memset(tb_result->a_, 0, chars * sizeof(char));
    memset(tb_result->b_, 0, chars * sizeof(char));

    //cal a recursive traceback function
    traceR(tb_result, view, a, b, 1, 0);
    //return results from above recursion
    return tb_result;
}

void freeResult(traceback_result *tb_result)
{
    //free up th ememory used for th eresults
    free(tb_result->a_);
    free(tb_result->b_);
    free(tb_result);
}