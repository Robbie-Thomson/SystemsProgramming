#include "Smith-Waterman.h"

#include "scoring_matrix.h"
#include "traceback.h"

#include <stdio.h>
#include <string.h>

//author - Robbie Thomson 2314819t

void print_smith_waterman(const char *a, const char *b)
{
    //print strings to be compared
    fprintf(stderr, "print_smith_waterman(\"%s\", \"%s\")\n", a, b);
    //initialise variabes
    int match_score = 3;
    int gap_cost = 2;
    //generate scoring matrix
    scoring_matrix matrix = create_matrix(a, b, match_score, gap_cost);
    scoring_matrix_view view = matrix_as_view(matrix);
    //print the values of the scoring matrix
    print_matrix(view);
    //call traceback function on scoring matrix
    traceback_result *tb_result = traceback(view, a, b);
    //print the results of the scoring matrix
    printf("A: %s\n", tb_result->a_);
    printf("B: %s\n", tb_result->b_);
    //free the memory used for the scoring matrix and the results of traceback
    free_matrix(matrix);
    freeResult(tb_result);
}
