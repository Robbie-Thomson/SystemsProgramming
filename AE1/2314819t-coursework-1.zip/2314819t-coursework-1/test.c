#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "Smith-Waterman.h"

int main()
{
    print_smith_waterman("GGTTGACTA", "TGTTACGG");
    return EXIT_SUCCESS;
}