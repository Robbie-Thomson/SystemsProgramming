# Coursework 1 - Systems Programming (H) 2019/2020

**This coursework is due on the 15th November 2019 16:00 UTC.**
**At that time you must have committed and pushed all your changes to the**
**master branch of stgit.dcs.gla.ac.uk**

The Smith–Waterman algorithm performs local sequence alignment.
It determines similar regions between two strings of nucleic acid
or protein sequences. In this coursework you implement this algorithm in
the C programming language.

You find the coursework description on moodle here:
https://moodle.gla.ac.uk/course/view.php?id=15388#section-6